MessageEntityType
=================

.. autoclass:: pyrogram.enums.MessageEntityType()
    :members:

.. raw:: html
    :file: ./cleanup.html