UserStatus
==========

.. autoclass:: pyrogram.enums.UserStatus()
    :members:

.. raw:: html
    :file: ./cleanup.html