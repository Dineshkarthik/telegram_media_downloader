MessageMediaType
================

.. autoclass:: pyrogram.enums.MessageMediaType()
    :members:

.. raw:: html
    :file: ./cleanup.html